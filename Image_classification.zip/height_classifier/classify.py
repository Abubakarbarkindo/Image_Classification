#!/usr/bin/env python3
"""
Height Classifier - Classifies humans in images as Short, Moderate, or Tall
Compatible with MediaPipe 0.10+ (new Tasks API)
"""

import os
os.environ["TF_CPP_MIN_LOG_LEVEL"]  = "3"
os.environ["GLOG_minloglevel"]       = "3"
os.environ["MEDIAPIPE_DISABLE_GPU"]  = "1"

import sys
import warnings
warnings.filterwarnings("ignore")

# Suppress absl logging (MediaPipe uses this)
try:
    import absl.logging
    absl.logging.set_verbosity(absl.logging.ERROR)
    absl.logging.use_absl_handler()
except Exception:
    pass

import cv2
import numpy as np

# Redirect stderr briefly to swallow remaining C++ logs
import ctypes, io

def check_dependencies():
    missing = []
    try:
        import mediapipe
    except ImportError:
        missing.append("mediapipe")
    try:
        import cv2
    except ImportError:
        missing.append("opencv-python")
    try:
        import numpy
    except ImportError:
        missing.append("numpy")
    if missing:
        print(f"[ERROR] Missing packages: {', '.join(missing)}")
        print(f"Run: pip install {' '.join(missing)}")
        sys.exit(1)

check_dependencies()

# Suppress all C++ / TensorFlow stderr output
import sys as _sys
_devnull = open(os.devnull, "w")
_old_stderr_fd = os.dup(2)
os.dup2(_devnull.fileno(), 2)

import mediapipe as mp
from mediapipe.tasks import python as mp_python
from mediapipe.tasks.python import vision as mp_vision
from mediapipe.tasks.python.vision import PoseLandmarker, PoseLandmarkerOptions

# Restore stderr for our own messages
os.dup2(_old_stderr_fd, 2)
os.close(_old_stderr_fd)
_devnull.close()

NOSE=0; LEFT_EYE=2; RIGHT_EYE=5
LEFT_SHOULDER=11; RIGHT_SHOULDER=12
LEFT_HIP=23; RIGHT_HIP=24
LEFT_KNEE=25; RIGHT_KNEE=26
LEFT_ANKLE=27; RIGHT_ANKLE=28
LEFT_FOOT=31; RIGHT_FOOT=32


def get_model_path():
    model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pose_landmarker.task")
    if not os.path.exists(model_path):
        print("  Downloading pose model (first run only, ~30MB)...")
        import urllib.request
        url = "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/latest/pose_landmarker_heavy.task"
        try:
            urllib.request.urlretrieve(url, model_path)
            print("  Model downloaded.\n")
        except Exception as e:
            print(f"[ERROR] Could not download model: {e}")
            sys.exit(1)
    return model_path


def classify_height(lm, img_w, img_h):
    def y(i): return lm[i].y * img_h
    def vis(i): return getattr(lm[i], 'visibility', 1.0)

    foot_idx  = LEFT_FOOT   if vis(LEFT_FOOT)   > vis(RIGHT_FOOT)   else RIGHT_FOOT
    ankle_idx = LEFT_ANKLE  if vis(LEFT_ANKLE)  > vis(RIGHT_ANKLE)  else RIGHT_ANKLE
    knee_idx  = LEFT_KNEE   if vis(LEFT_KNEE)   > vis(RIGHT_KNEE)   else RIGHT_KNEE
    hip_idx   = LEFT_HIP    if vis(LEFT_HIP)    > vis(RIGHT_HIP)    else RIGHT_HIP
    sh_idx    = LEFT_SHOULDER if vis(LEFT_SHOULDER) > vis(RIGHT_SHOULDER) else RIGHT_SHOULDER

    top_y    = y(NOSE)
    bottom_y = max(y(foot_idx), y(ankle_idx))
    body_span = abs(bottom_y - top_y)
    if body_span < 1:
        return "Unknown", 0.0, {}

    span_frac = body_span / img_h
    hip_y = y(hip_idx); knee_y = y(knee_idx); ankle_y = y(ankle_idx)
    upper_leg = abs(knee_y - hip_y)
    lower_leg = abs(ankle_y - knee_y)
    total_leg = upper_leg + lower_leg
    leg_ratio = total_leg / body_span if body_span > 0 else 0.5
    torso = abs(y(hip_idx) - y(sh_idx))
    torso_leg = torso / total_leg if total_leg > 0 else 1.0
    eye_y = (y(LEFT_EYE) + y(RIGHT_EYE)) / 2
    head_h = abs(eye_y - y(NOSE)) * 3.5
    head_ratio = head_h / body_span if body_span > 0 else 0.15

    def sc_span(f):
        if f>=0.72: return 1.0
        if f>=0.62: return 0.5
        if f>=0.52: return 0.0
        if f>=0.42: return -0.5
        return -1.0
    def sc_leg(r):
        if r>=0.57: return 1.0
        if r>=0.53: return 0.4
        if r>=0.49: return 0.0
        if r>=0.45: return -0.4
        return -1.0
    def sc_torso(tl):
        if tl<=0.78: return 1.0
        if tl<=0.88: return 0.4
        if tl<=0.98: return 0.0
        if tl<=1.10: return -0.4
        return -1.0
    def sc_head(hr):
        if hr<=0.13: return 1.0
        if hr<=0.15: return 0.4
        if hr<=0.17: return 0.0
        if hr<=0.19: return -0.4
        return -1.0

    total = 0.30*sc_span(span_frac) + 0.30*sc_leg(leg_ratio) + 0.20*sc_torso(torso_leg) + 0.20*sc_head(head_ratio)

    if total >= 0.25:   label, conf = "Tall",     min(0.99, 0.65 + total*0.3)
    elif total <= -0.25: label, conf = "Short",   min(0.99, 0.65 + abs(total)*0.3)
    else:                label, conf = "Moderate", min(0.99, 0.60 + (0.25-abs(total))*0.5)

    debug = {"span_frac": round(span_frac,3), "leg_ratio": round(leg_ratio,3),
             "torso_leg": round(torso_leg,3), "head_ratio": round(head_ratio,3),
             "weighted_score": round(total,3)}
    return label, round(conf,2), debug


def draw_results(image, lm, label, confidence, img_w, img_h):
    annotated = image.copy()
    connections = [(11,12),(11,13),(13,15),(12,14),(14,16),(11,23),(12,24),(23,24),
                   (23,25),(25,27),(27,31),(24,26),(26,28),(28,32),(0,11),(0,12)]
    for s,e in connections:
        x1,y1 = int(lm[s].x*img_w), int(lm[s].y*img_h)
        x2,y2 = int(lm[e].x*img_w), int(lm[e].y*img_h)
        cv2.line(annotated,(x1,y1),(x2,y2),(255,255,255),2)
    for i in range(33):
        cx,cy = int(lm[i].x*img_w), int(lm[i].y*img_h)
        cv2.circle(annotated,(cx,cy),4,(0,255,120),-1)
    colours = {"Tall":(0,200,50),"Moderate":(30,160,255),"Short":(0,60,220)}
    colour = colours.get(label,(200,200,200))
    overlay = annotated.copy()
    cv2.rectangle(overlay,(0,0),(img_w,60),(20,20,20),-1)
    cv2.addWeighted(overlay,0.75,annotated,0.25,0,annotated)
    text = f"{label.upper()}  ({confidence*100:.0f}%)"
    font,scale,thick = cv2.FONT_HERSHEY_DUPLEX,1.1,2
    tw,_ = cv2.getTextSize(text,font,scale,thick)[0]
    cv2.putText(annotated,text,((img_w-tw)//2,42),font,scale,colour,thick,cv2.LINE_AA)
    return annotated


def _suppress_stderr():
    devnull = open(os.devnull, "w")
    old_fd = os.dup(2)
    os.dup2(devnull.fileno(), 2)
    return devnull, old_fd

def _restore_stderr(devnull, old_fd):
    os.dup2(old_fd, 2)
    os.close(old_fd)
    devnull.close()

def make_landmarker():
    model_path = get_model_path()
    base_options = mp_python.BaseOptions(model_asset_path=model_path)
    options = PoseLandmarkerOptions(
        base_options=base_options,
        output_segmentation_masks=False,
        num_poses=1,
        min_pose_detection_confidence=0.5,
        min_pose_presence_confidence=0.5,
        min_tracking_confidence=0.5,
    )
    dn, fd = _suppress_stderr()
    lm = PoseLandmarker.create_from_options(options)
    _restore_stderr(dn, fd)
    return lm


def process_image(image_path, save_output=True, verbose=False):
    if not os.path.isfile(image_path):
        print(f"[ERROR] File not found: {image_path}")
        return None, None, None

    image = cv2.imread(image_path)
    if image is None:
        print(f"[ERROR] Cannot read image: {image_path}")
        return None, None, None

    img_h, img_w = image.shape[:2]

    with make_landmarker() as landmarker:
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB,
                            data=cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        dn, fd = _suppress_stderr()
        result = landmarker.detect(mp_image)
        _restore_stderr(dn, fd)

    if not result.pose_landmarks or len(result.pose_landmarks) == 0:
        print(f"[WARN]  No human pose detected in: {os.path.basename(image_path)}")
        print("        Tip: use a full-body photo where head and feet are both visible.")
        return "Unknown", 0.0, {}

    lm = result.pose_landmarks[0]
    label, conf, debug = classify_height(lm, img_w, img_h)

    if verbose:
        print("\n  ── Debug features ──────────────────────")
        for k,v in debug.items():
            print(f"     {k:20s}: {v}")
        print("  ────────────────────────────────────────")

    if save_output:
        annotated = draw_results(image, lm, label, conf, img_w, img_h)
        base, ext = os.path.splitext(image_path)
        out_path  = base + "_result" + (ext if ext else ".jpg")
        cv2.imwrite(out_path, annotated)
        print(f"  Saved annotated image → {out_path}")

    return label, conf, debug


def process_video(video_path, save_output=True, verbose=False):
    if not os.path.isfile(video_path):
        print(f"[ERROR] File not found: {video_path}")
        return
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"[ERROR] Cannot open video: {video_path}")
        return
    fps   = cap.get(cv2.CAP_PROP_FPS) or 25
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height= int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    base, _ = os.path.splitext(video_path)
    out_path = base + "_result.mp4"
    writer = None
    if save_output:
        writer = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
    frame_idx = 0
    label_counts = {"Tall":0,"Moderate":0,"Short":0,"Unknown":0}
    with make_landmarker() as landmarker:
        while True:
            ret, frame = cap.read()
            if not ret: break
            frame_idx += 1
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB,
                                data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            result = landmarker.detect(mp_image)
            if result.pose_landmarks and len(result.pose_landmarks) > 0:
                lm = result.pose_landmarks[0]
                label, conf, _ = classify_height(lm, width, height)
                label_counts[label] = label_counts.get(label,0)+1
                annotated = draw_results(frame, lm, label, conf, width, height)
            else:
                label_counts["Unknown"] += 1
                annotated = frame.copy()
            if save_output and writer: writer.write(annotated)
            if frame_idx % 30 == 0:
                print(f"  Frame {frame_idx}/{total}  ({frame_idx/max(total,1)*100:.0f}%)", end="\r")
    cap.release()
    if writer: writer.release()
    print(f"\n  Processed {frame_idx} frames.")
    dominant = max(label_counts, key=label_counts.get)
    print(f"  Overall classification: {dominant.upper()}")
    if save_output: print(f"  Saved annotated video → {out_path}")


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Height Classifier — Short / Moderate / Tall",
        epilog="Examples:\n  python classify.py person.jpg\n  python classify.py video.mp4\n  python classify.py images/",
        formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("input",     help="Image file, video file, or folder")
    parser.add_argument("--no-save", action="store_true", help="Don't save annotated output")
    parser.add_argument("--verbose", action="store_true", help="Show debug scores")
    args = parser.parse_args()
    save = not args.no_save
    path = args.input
    VIDEO_EXT = {".mp4",".avi",".mov",".mkv",".webm"}
    IMAGE_EXT = {".jpg",".jpeg",".png",".bmp",".tiff",".tif",".webp",".jfif"}

    if os.path.isdir(path):
        files = [os.path.join(path,f) for f in sorted(os.listdir(path))
                 if os.path.splitext(f)[1].lower() in IMAGE_EXT]
        if not files:
            print("[ERROR] No images found in folder."); sys.exit(1)
        print(f"Found {len(files)} image(s)\n")
        for fp in files:
            print(f"► {os.path.basename(fp)}")
            label, conf, _ = process_image(fp, save_output=save, verbose=args.verbose)
            if label: print(f"  Result: {label.upper()}  ({conf*100:.0f}%)\n")
    elif os.path.splitext(path)[1].lower() in VIDEO_EXT:
        print(f"► Processing video: {path}\n")
        process_video(path, save_output=save, verbose=args.verbose)
    elif os.path.isfile(path):
        print(f"► Processing image: {path}\n")
        label, conf, _ = process_image(path, save_output=save, verbose=args.verbose)
        if label and label != "Unknown":
            print(f"\n  ┌─────────────────────────────┐")
            print(f"  │  Classification : {label:<10s} │")
            print(f"  │  Confidence     : {conf*100:>5.1f}%     │")
            print(f"  └─────────────────────────────┘\n")
        elif label == "Unknown":
            print("  Classification: Unknown (no pose detected)\n")
    else:
        print(f"[ERROR] Not found or unsupported: {path}"); sys.exit(1)

if __name__ == "__main__":
    main()
