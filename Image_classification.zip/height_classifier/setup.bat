@echo off
echo ============================================
echo  Height Classifier - Setup
echo ============================================
echo.

REM Check Python
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python not found. Please install Python 3.8+ from https://python.org
    pause
    exit /b 1
)

echo [OK] Python found
echo.
echo Installing dependencies...
pip install -r requirements.txt

IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Installation failed. Try running as Administrator.
    pause
    exit /b 1
)

echo.
echo ============================================
echo  Setup complete! You can now run:
echo.
echo    python classify.py YOUR_IMAGE.jpg
echo    python classify.py YOUR_VIDEO.mp4
echo    python classify.py images_folder/
echo ============================================
pause
