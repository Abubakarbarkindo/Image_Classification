#!/usr/bin/env python3
"""
test_install.py  –  Verifies all dependencies are installed correctly.
Run this before classify.py to confirm your setup is good.
"""
import sys

print("Height Classifier — Installation Check")
print("=" * 40)

ok = True

# Python version
major, minor = sys.version_info[:2]
status = "OK" if (major == 3 and minor >= 8) else "WARN"
print(f"[{status}] Python {major}.{minor}  (need 3.8+)")
if status == "WARN":
    ok = False

# mediapipe
try:
    import mediapipe as mp
    print(f"[OK] mediapipe  {mp.__version__}")
except ImportError:
    print("[FAIL] mediapipe  — run: pip install mediapipe")
    ok = False

# opencv
try:
    import cv2
    print(f"[OK] opencv     {cv2.__version__}")
except ImportError:
    print("[FAIL] opencv-python  — run: pip install opencv-python")
    ok = False

# numpy
try:
    import numpy as np
    print(f"[OK] numpy      {np.__version__}")
except ImportError:
    print("[FAIL] numpy  — run: pip install numpy")
    ok = False

print("=" * 40)
if ok:
    print("All checks passed! You can run classify.py now.")
else:
    print("Some checks failed. Fix the issues above, then retry.")
    sys.exit(1)
