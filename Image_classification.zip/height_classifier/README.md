# Height Classifier
Classifies humans in images/videos as **Short**, **Moderate**, or **Tall**
using Google's **MediaPipe Pose** landmark model.

---

## How It Works

1. **MediaPipe Pose** detects 33 body landmarks (nose, eyes, shoulders, hips,
   knees, ankles, feet) with sub-pixel accuracy.
2. Four body-proportion features are extracted — all normalised so the result
   is independent of image resolution or camera distance:
   - **Body span fraction** — how much of the frame height the person occupies
   - **Leg ratio** — leg length / total body height
   - **Torso-to-leg ratio** — relative leg elongation
   - **Head size ratio** — head height / body height (smaller → taller)
3. A weighted vote across the four features produces the final label.

> **Note:** Because the classifier uses *relative proportions* rather than
> absolute pixel size, it works best when the *full body* (head to feet) is
> visible in the image. Cropped or very close-up shots reduce accuracy.

---

## Requirements

- Python 3.8 or higher
- pip (comes with Python)

---

## Installation

### Windows
```
setup.bat
```

### Linux / macOS
```
chmod +x setup.sh
./setup.sh
```

### Manual (any OS)
```
pip install -r requirements.txt
```

---

## Usage

### Single image
```
python classify.py photo.jpg
```

### Single image — verbose (show internal feature values)
```
python classify.py photo.jpg --verbose
```

### Single image — no saved output
```
python classify.py photo.jpg --no-save
```


```
python classify.py my_images/
```

---

## Output

- **Terminal**: label + confidence printed to the console.
- **Saved file**: an annotated copy is written next to the original, e.g.
  `photo_result.jpg` or `video_result.mp4`.

---

## Tips for Best Results

| Do | Avoid |
|----|-------|
| Full-body photos (head to feet visible) | Cropped / portrait shots |
| One person clearly in frame | Multiple overlapping people |
| Good lighting, clear background | Dark / blurry images |
| Person standing upright | Sitting, crouching, lying down |

---

## Examples

```
python classify.py tall_person.jpg
► Processing image: tall_person.jpg

  ┌─────────────────────────────┐
  │  Classification : Tall       │
  │  Confidence     :  82.0%     │
  └─────────────────────────────┘

  Saved annotated image → tall_person_result.jpg
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `No module named mediapipe` | Run `pip install mediapipe` |
| `No pose detected` | Make sure the full body is visible |
| OpenCV import error on Linux | `sudo apt install libgl1` |
| Slow on video | Normal — MediaPipe runs CPU inference per frame |

## ⚠️ Model File Setup

The `pose_landmarker.task` model file is **not included** in this repo (too large for GitHub).

**Download it manually:**
```bash
wget -q https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/latest/pose_landmarker_heavy.task -O pose_landmarker.task
```
Or visit: https://developers.google.com/mediapipe/solutions/vision/pose_landmarker

Place the downloaded file in the same folder as `classify.py`.
