#!/bin/bash

echo "============================================"
echo " Height Classifier - Setup"
echo "============================================"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 not found. Install it first:"
    echo "  Ubuntu/Debian : sudo apt install python3 python3-pip"
    echo "  macOS         : brew install python3"
    exit 1
fi

echo "[OK] Python 3 found: $(python3 --version)"
echo ""
echo "Installing dependencies..."
echo ""

pip3 install -r requirements.txt

if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] Installation failed."
    echo "Try: pip3 install --user -r requirements.txt"
    exit 1
fi

echo ""
echo "============================================"
echo " Setup complete! You can now run:"
echo ""
echo "   python3 classify.py YOUR_IMAGE.jpg"
echo "   python3 classify.py YOUR_VIDEO.mp4"
echo "   python3 classify.py images_folder/"
echo "============================================"
